"""
 [10 Questions] QUIZ - File Operations
"""

# --------------------------------------------------------------------------------------#

# Q 1:
import fnmatch
import pathlib
import shutil

"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And print the flower names.

Hints:
* os
* read mode ('r')
"""

# S 1:
# flowers = open('quiz_files/flower_names.txt', encoding='utf-8', mode = 'r')
# print(flowers.read())


# --------------------------------------------------------------------------------------#

# Q 2:
"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And append the name below to this file:

'Z: Zinnia elegans'

Finally print all the file content.

Hints:
* os
* append mode ('a')
"""

# S 2:
# flowers = open('quiz_files/flower_names.txt', encoding='utf-8', mode='a')
# flowers.write('\nZ: Zinnia elegans')


# --------------------------------------------------------------------------------------#

# Q 3:
"""
Create a file named 'quiz_files/file_to_delete.txt'.
And add the content below into this file:
'This file will be deleted in the Quiz.'

Hints:
* os
* to create file -> mode='x'
* encoding
"""

# S 3:
# with open('quiz_files/file_to_delete', mode='x', encoding='utf-8') as new_file:
#     new_file.write('This file will be deleted in the Quiz.')


# --------------------------------------------------------------------------------------#

# Q 4:
"""
Delete the file 'quiz_files/file_to_delete.txt' you created in Q3.
Add exception handling to handle the case of not finding such a file.

Hints:
* os
* try-except
* to delete -> os.remove()
"""

# S 4:
import os
path = 'quiz_files/file_to_delete'
# try:
#     os.remove(path)
# except FileNotFoundError:
#     print('File not found')


# --------------------------------------------------------------------------------------#

# Q 5:
"""
Get the list of all content (files and folders) in this project directory.
Use this methods:
1- os.listdir()
2- os.scandir()
3- pathlib.Path.iterdir()

Hints:
* os
* pathlib
"""

# S 5:
path = os.getcwd()
# Method 1
# content = os.listdir()
# for c in content:
#     print(c)

# Method 2
# content = os.scandir()
# for c in content:
#     print(c)

# Method 3
# from pathlib import Path
# content = Path(path)
# for c in content.iterdir():
#     print(c)

# --------------------------------------------------------------------------------------#

# Q 6:
"""
Create the folder tree below in the 'quiz_files' directory:

- quiz_files
    - folder 1
        - sub folder 1
        - sub folder 2
    - folder 2
    - folder 3
        - sub folder 3

Create all of them one by one with os.mkdir().

Hints:
* os
* os.mkdir()
"""

# S 6:
# import os
# import shutil
#
# shutil.rmtree('quiz_files_2')
# os.mkdir('quiz_files_2')
# os.mkdir('quiz_files_2/folder 1')
# os.mkdir('quiz_files_2/folder 1/sub folder 1')
# os.mkdir('quiz_files_2/folder 1/sub folder 2')
# os.mkdir('quiz_files_2/folder 2')
# os.mkdir('quiz_files_2/folder 3')
# os.mkdir('quiz_files_2/folder 3/sub folder 3')

# --------------------------------------------------------------------------------------#

# Q 7:
"""
Create the folder tree below in the 'quiz_files' directory.
This time create with the methods described in parenthesis.

- quiz_files

    (os.makedirs)
    - folder 10
        - sub folder 10
        - sub folder 20
    
    (pathlib.Path.mkdir)
    - folder 20
    
    (pathlib.Path.mkdir)
    - folder 30
        - sub folder 30
        
Handle 'FileExistsError' exception if the file already exists.

Hints:
* os
* os.makedirs()
* pathlib.Path.mkdir()
* exist_ok=True
* parents
"""

# SOLUTION 7:

# import os
# from pathlib import Path
#
# try:
#     os.makedirs('quiz_files_3/folder 10/sub folder 10')
#     os.makedirs('quiz_files_3/folder 10/sub folder 20')
# except Exception as e:
#     print(e)
#
# pathlib.Path('quiz_files_3/folder 20').mkdir(exist_ok=True)
#
# pathlib.Path('quiz_files_3/folder 30/sub folder 30').mkdir(parents=True, exist_ok=True)


# --------------------------------------------------------------------------------------#

# Q 8:
"""
Find all the files which has '*a*d*.py' in the file name.
Use Comprehension both getting the list and printing it.

Hints:
* os
* os.scandir()
* os.getcwd()
* fnmatch
"""

# S 8:
# pattern = '*a*d*.py'
# import os
# import fnmatch
#
# for f in os.scandir():
#     if fnmatch.fnmatch(f.name, pattern):
#         print(f)


# --------------------------------------------------------------------------------------#

# Q 9:
"""
Delete all the files and folders which has '1' in its name.

Use os.path.join to join the current project path (os.getcwd) and 'quiz_files'.
And make it as your search path.

Use single Comprehension to find and delete them.

Hints:
* shutil.rmtree()
* os.getcwd()
* os.path.join()
"""

# S 9:
search_path = os.path.join(os.getcwd(), 'quiz_files_3')
print(search_path)

for f in os.scandir(search_path):
    if fnmatch.fnmatch(f.name, '*1*'):
        shutil.rmtree(f)


# --------------------------------------------------------------------------------------#

# Q 10:
"""
Create an archive (zip) folder out of 'quiz_files' folder.
The name of the archive folder is going to be 'quiz_folder_archive.zip'.

Hints:
* shutil.make_archive()
"""

# S 10:

import zipfile
import shutil

archive = zipfile.ZipFile('neural_style_transfer.zip')
archive.extractall()
archive.close()

shutil.make_archive('quiz_folder_archive_zip', 'zip', 'quiz_files_2')



# --------------------------------------------------------------------------------------#