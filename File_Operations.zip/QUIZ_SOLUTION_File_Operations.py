"""
 [10 Questions] QUIZ - File Operations
"""

# --------------------------------------------------------------------------------------#

# Q 1:
"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And print the flower names.

Hints:
* os
* read mode ('r')
"""

# S 1:
path = 'quiz_files/flower_names.txt'
# 1st Way:
# with open(path) as file:
#     flowers = file.read()
#     print(flowers)

# 2nd Way
# with open(path, mode='r') as file:
#     for flower in file:
#         # \n char -> split()
#         # print(flower.split())
#         print(flower, end='')

# --------------------------------------------------------------------------------------#

# Q 2:
"""
Open the 'quiz_files/flower_names.txt' file in this project with Python.
And append the name below to this file:

'Z: Zinnia elegans'

Finally print all the file content.

Hints:
* os
* append mode ('a')
"""

# S 2:

path = 'quiz_files/flower_names.txt'
new_flower = 'Z: Zinnia elegans'

# with open(path, mode='a') as file:
#     # create an empty line -> \n
#     file.write('\n')
#
#     # add the new flower
#     file.write(new_flower)

# --------------------------------------------------------------------------------------#

# Q 3:
"""
Create a file named 'quiz_files/file_to_delete.txt'.
And add the content below into this file:
'This file will be deleted in the Quiz.'

Hints:
* os
* to create file -> mode='x'
* encoding
"""

# S 3:
import os

path = 'quiz_files/file_to_delete.txt'

# with open(path, mode='x', encoding='utf-8') as file:
#     file.write('This file will be deleted in the Quiz.')
#     print(file)


# --------------------------------------------------------------------------------------#

# Q 4:
"""
Delete the file 'quiz_files/file_to_delete.txt' you created in Q3.
Add exception handling to handle the case of not finding such a file.

Hints:
* os
* try-except
* to delete -> os.remove()
"""

# S 4:
import os

path = 'quiz_files/file_to_delete.txt'

# try:
#     os.remove(path)
# except:
#     print('File not found.')

# --------------------------------------------------------------------------------------#

# Q 5:
"""
Get the list of all content (files and folders) in this project directory.
Use this methods:
1- os.listdir()
2- os.scandir()
3- pathlib.Path.iterdir()

Hints:
* os
* pathlib
"""

# S 5:

import os
from pathlib import Path

# 1st Way:
# for content in os.listdir():
#     print(content)

# 2nd Way
# for content in os.scandir():
#     print(content.name)

# 3rd Way
# . -> current folder location
# for content in Path('.').iterdir():
#     print(content)

# --------------------------------------------------------------------------------------#

# Q 6:
"""
Create the folder tree below in the 'quiz_files' directory:

- quiz_files
    - folder 1
        - sub folder 1
        - sub folder 2
    - folder 2
    - folder 3
        - sub folder 3

Create all of them one by one with os.mkdir().

Hints:
* os
* os.mkdir()
"""

# S 6:
# import os
#
# os.mkdir('quiz_files/folder 1')
# os.mkdir('quiz_files/folder 1/sub folder 1')
# os.mkdir('quiz_files/folder 1/sub folder 2')
#
# os.mkdir('quiz_files/folder 2')
#
# os.mkdir('quiz_files/folder 3')
# os.mkdir('quiz_files/folder 3/sub folder 3')


# --------------------------------------------------------------------------------------#

# Q 7:
"""
Create the folder tree below in the 'quiz_files' directory.
This time create with the methods described in parenthesis.

- quiz_files

    (os.makedirs)
    - folder 10
        - sub folder 10
        - sub folder 20
    
    (pathlib.Path.mkdir)
    - folder 20
    
    (pathlib.Path.mkdir)
    - folder 30
        - sub folder 30
        
Handle 'FileExistsError' exception if the file already exists.

Hints:
* os
* os.makedirs()
* pathlib.Path.mkdir()
* exist_ok=True
* parents
"""

# Çözüm 7:
import os
from pathlib import Path

# os.makedirs('quiz_files/folder 10/sub folder 10', exist_ok=True)
# os.makedirs('quiz_files/folder 10/sub folder 20', exist_ok=True)
#
# Path('quiz_files/folder 20').mkdir(exist_ok=True)
# Path('quiz_files/folder 30/sub folder 30').mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------------------#

# Q 8:
"""
Find all the files which has '*a*d*.py' in the file name.
Use Comprehension both getting the list and printing it.

Hints:
* os
* os.scandir()
* os.getcwd()
* fnmatch
"""

# S 8:
import os
import fnmatch

# pattern = '*a*d*.py'
#
# files = [file.name
#          for file in os.scandir()
#          if file.is_file() and fnmatch.fnmatch(file.name, pattern)]
#
# # print(files)
#
# [print(f) for f in files]

# --------------------------------------------------------------------------------------#

# Q 9:
"""
Delete all the files and folders which has '1' in its name.

Use os.path.join to join the current project path (os.getcwd) and 'quiz_files'.
And make it as your search path.

Use single Comprehension to find and delete them.

Hints:
* shutil.rmtree()
* os.getcwd()
* os.path.join()
"""

# S 9:
import os
import shutil
import fnmatch

project_path = os.getcwd()
search_path = os.path.join(project_path, 'quiz_files')
# print(search_path)

pattern = '*1*'

# find the files with pattern
# [print(content.name)
#  for content in os.scandir(search_path)
#  if fnmatch.fnmatch(content.name, pattern)]
#
# [shutil.rmtree(content)
#  for content in os.scandir(search_path)
#  if fnmatch.fnmatch(content.name, pattern)]

# --------------------------------------------------------------------------------------#

# Q 10:
"""
Create an archive (zip) folder out of 'quiz_files' folder.
The name of the archive folder is going to be 'quiz_folder_archive.zip'.

Hints:
* shutil.make_archive()
"""

# S 10:
import shutil

shutil.make_archive('quiz_folder_archive', 'zip', 'quiz_files')


# --------------------------------------------------------------------------------------#