"""
File is a set of bytes that store data.

"""

"""
File Types:

1 - Binary Types
    * pdf, doc, jpg, png
    
2 - Text Types
    * txt, xml, html, .py, .java
"""

"""
Encoding defines how data is stored in a file.

Contain encodings:
1 - ASCII (128 Characters)
2 - UNICODE (1,114,112 Characters)

"""

# Reading a file without encoding

# file = open('words.txt')
# print(file.read())
# without encoding some special characters are not read properly such as 'Euro' Symbol


# Reading a file with encoding

# file = open('words.txt', encoding='utf-8')
# print(file.read())

# Important
# You should always close the file you opened.

# file.close()
# print('File is closed.')

# What happens if the file doesn't exist -> It raises error
# FileNotFoundError: [Errno 2] No such file or directory: 'words2.txt'
#
# file2 = open('words2.txt')
# print(file2.read())

# Exception Handling
# It's a good practice to always use exception handling so that errors can be mitigated from starting itself.

# try:
#     file = open('words.txt', encoding='utf-8')
# except:
#     print('No such file exists in the path.')
# else:
#     print(file.read())
#     file.close()
#     print('file is closed.')


"""
With method for reading a file and it automatically closes the file.
"""

# with open('wordss.txt', encoding='utf-8') as file:
#     content = file.read()
#     print(content)

# using exception handling (Good practice)

# try:
#     with open('wordss.txt', encoding='utf-8') as file:
#         content = file.read()
#         print(content)
#
# except FileNotFoundError:
#     print('No such file exists in the path...')
#     print('please check your file name.')


"""
Binary Modes

r - read
w - write
t - text
a - append
x - create
b - binary file
+ - update (read and write)
"""

# Ex: open a file in READ mode
# r -> opening a file in read mode
# rt -> reading a file as text

with open('words.txt', encoding='utf-8', mode='r') as file:
    print(file.read())







