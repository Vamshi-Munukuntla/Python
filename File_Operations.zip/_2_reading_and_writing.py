"""
Reading - Writing
"""

"""
Reading Methods:

* read() -> all content at once
* readline() -> reads single line and waits for the next one
* readlines() -> reads all the remaining lines

"""

# Ex -> Reading

# with open('lorem_ipsum.txt', mode='rt', encoding='utf-8') as lorem:
#     print(lorem.read())

# Ex -> Reading first 50 Characters

# with open('lorem_ipsum.txt', encoding='utf-8', mode='rt') as lorem:
#     content = lorem.read(50)    # read first 50 characters
#     print(content)

# Read the file line by line
# with open('lorem_ipsum.txt', encoding='utf-8', mode='rt') as lorem:
#     line_1 = lorem.readline()
#     print(line_1)

# Reading the file line by line -> read first two lines
# with open('lorem_ipsum.txt', encoding='utf-8', mode='rt') as lorem:
#     line_1 = lorem.readline()
#     print(line_1)
#     line_2 = lorem.readline()
#     print(line_2)

# read all the lines one by one -> for loop
# with open('lorem_ipsum.txt', encoding='utf-8', mode='rt') as lorem:
#     for line in lorem:
#         print(line)

# read all the lines one by one -> for loop with split
# with open('lorem_ipsum.txt', encoding='utf-8', mode='rt') as lorem:
#     for line in lorem:
#         # splits the text from space chars -> ' ', \n, \t
#         line_content = line.split()
#         print(line_content)


"""
Writing Modes:
* w: Write -> clear all the information in the file and open as blank file (DANGEROUS)
* a: append -> appends the new info to the existing file (SAFE)
"""

# Open a file with write mode
# with open('lorem_ipsum_copy.txt', mode='w') as writing:
#     writing.write('Only this line will be available')


# Open with append mode
with open('lorem_ipsum.txt', mode = 'a') as lorem:
    lorem.write('\nThis is also included along with previous notes.')

# append multiple lines at once
with open('lorem_ipsum.txt', mode='a') as lorem:
    list_to_append = ['\nMulti Line 1', '\nMulti Line 2', '\nMulti Line 3']
    lorem.writelines(list_to_append)















