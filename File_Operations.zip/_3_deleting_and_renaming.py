"""
We use 'os' module to :
* rename
* delete
* create
files
"""

import os

# RENAME
# try:
#     if not os.path.isdir('file_to_delete.txt'):
#         os.mkdir('file_to_delete.txt')
#         os.rename('file_to_delete.txt', 'file_to_rename2.txt')
#     else:
#         os.mkdir('file_to_delete.txt')
#         os.rename('file_to_delete.txt','file_to_rename2.txt')
# except FileNotFoundError:
#     print(FileNotFoundError)
# except FileExistsError:
#     print('File Already exists')

# DELETE -> remove(), unlink()

# os.remove("file_to_delete.txt")

# os.unlink('unlink.txt')

# CREATE -> mode = 'x'

try:
    with open('file_not_exists_yet.txt', mode='x') as new_file:
        new_file.write('created a new file just now.')
except FileExistsError:
    print('File Already exists')
    print('please change the file name to create a new one.')








