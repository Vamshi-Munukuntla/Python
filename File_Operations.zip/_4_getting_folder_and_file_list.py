"""
Content Types inside a folder:
1 - File
2 - Folder (Directory)
"""

# ----------- Get All Contents ---------- #

# Method 1 -> os.listdir()

import os
# the project path
path = os.getcwd()

# content = os.listdir(path)
# for c in content:
#     print(c)


# Method 2 -> os.scandir()
# folder = os.scandir(path)
# for f in folder:
#     print(f)


# Method 3 -> pathlib.Path.iterdir()

# from pathlib import Path
# content = Path(path)
# for c in content.iterdir():
#     print(c)

# -------------------- Get All Files --------------#

# Method 1 -> os.listdir()
# os.path.isfile()

# content = os.listdir(path)
# for c in content:
#     if os.path.isfile(c):
#         print(c)


# Method 2 -> os.scandir()
# os.is_file()

# content = os.scandir(path)
# for c in content:
#     if c.is_file():
#         print(c)


# --------------------------Get All Folders --------------#

# Method 1 -> os.listdir()
# os.isdir()
# content = os.listdir(path)
# for c in content:
#     if os.path.isdir(c):
#         print(c)


# Method 2 -> os.scandir()
# os.isdir()
# content = os.scandir(path)
# for c in content:
#     if os.path.isdir(c):
#         print(c)


# Method 3 -> pathlib.Path.iterdir()

from pathlib import Path

content = Path(path)
for c in content.iterdir():
    if c.is_dir():
        print(c)














