"""
To create directory / directories:

1 - os.mkdir()
    *   mkdir    -> creates single directory
    * makedirs() -> multiple directories

2 - pathlib.Path.mkdir() -> Single and Multiple directories
"""

# SINGLE DIRECTORY
import os
import pathlib
from pathlib import Path

# Method 1 - Using os.mkdir()

# if not os.path.isdir('New_Folder'):
#     os.mkdir('New_Folder')

# Method 2 - Using pathlib.Path.mkdir()

# p = Path('path_folder_1')
# p.mkdir()

# ---------------------------------------------------------#
#
# CREATING MULTIPLE DIRECTORIES

"""
Directory Structure / tree
    - level1
        - level2
            -level3
"""

# Method 1 -> os.makedirs()
# os.makedirs('level1/level2/level3')

# FileExistsError -> to overcome -> exist_ok
# os.makedirs('level1/level2/level3',exist_ok=True)


# Method 2 -> pathlib.Path.mkdir()
p2 = Path('pathlevel1/pathlevel2/pathlevel3/pathlevel4')
# p2.mkdir(parents=True)

# FileAlreadyExistsError
# p2.mkdir(parents=True, exist_ok=True)

try:
    file = open('_6_searching_files_and_folders.py', mode='x')
except:
    print('File already exists')











