"""
Two ways to search:

1 - String Methods -> startswith, endswith, find

2 - fnmatch module (recommended)
"""

# --------------------Method 1--------------------------#

import os
from pathlib import Path

# Search Path
# if your strings contains \ char -> 'r' in front of string -> raw string
search_path = r'C:\Windows'
# print(search_path)

# for s in os.listdir(search_path):
#     print(s)


# Lets get only .exe files

# long and tedious way
# with -> Context Manager
# with Path(search_path) as search:
#     files = search.iterdir()
#     for content in files:
#         if content.name.endswith('.exe') and content.is_file():
#             print(content)


# --------------------Method 2--------------------------#

import fnmatch

pattern = '*.exe'
with Path(search_path) as folder:
    for f in folder.iterdir():
        if fnmatch.fnmatch(f.name, pattern):
            print(f)








