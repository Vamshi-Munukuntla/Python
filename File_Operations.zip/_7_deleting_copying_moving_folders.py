import os
import pathlib
from pathlib import Path
import shutil

# 1 - DELETE FOLDERS
"""
1. os.rmdir()           ->  if empty
2. pathlib.Path.rmdir() ->  if empty
3. shutil.rmtree()      ->  removes all
"""

# if not os.path.isdir('folder_to_delete_1'):
#     os.mkdir('folder_to_delete_1')
#
# if not os.path.isdir('folder_to_delete_2'):
#     os.mkdir('folder_to_delete_2')

# Creating files inside folder

# with open('folder_to_delete_2/python1.txt', mode='x') as inside_file:
#     inside_file.write('created a file')

# os
# try:
#     os.rmdir('folder_to_delete_1')
# except OSError as e:
#     print(e)

# pathlib
# try:
#     pathlib.Path('folder_to_delete_1').rmdir()
# except OSError as e:
#     print(e)

# shutil
# shutil.rmtree('folder_to_delete_1')

# ------------------------------------------------------------------------------- #
# 2 - COPY FILES AND FOLDERS

# FILES

# shutil.copy()
# shutil.copy2()
# Source -> Destination

# os.mkdir('source')
# os.mkdir('destination')
# with open('source/source.txt', mode='x') as create_file:
#     create_file.write('this file will be copied to destination folder')

# Copying a file
# src = 'source/source.txt'
# dest = 'destination'
# shutil.copy(src, dest)
#
# Copying a file and renaming it
# src = 'source/source.txt'
# dest = 'destination/final_file.txt'
# shutil.copy(src, dest)


# Copying Folders
# shutil.copytree('source', 'source_copy')


# --------------------------------------------------------------------------------- #
# 3 - MOVING FOLDERS AND FILES


# FILES
# shutil.move('source/source.txt', 'folder_to_delete_2')
# shutil.move('folder_to_delete_2/python2.txt', 'source')
# shutil.move('source_copy', 'source')


with open('_8_reading_and_creating_archive_files.py',mode='x') as new_file:
    new_file
