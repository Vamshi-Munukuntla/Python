"""
ARCHIVE FILE operations
zipfile
"""

import os
import shutil
import zipfile
import fnmatch
from pathlib import Path

# path = os.getcwd()
# pattern = '*.py'
# with Path(path) as final:
#     for f in final.iterdir():
#         if fnmatch.fnmatch(f.name, pattern):
#             print(f)


# for d in os.scandir():
#     print(d)

# let's open a zip file
# archive = zipfile.ZipFile('neural_style_transfer.zip', mode='r')
# print(archive)
#
# # let's see what's in the zip file
# for d in archive.filelist:
#     print(d)
#
# # extract files from zipfile
# archive.extractall()
# archive.close()
#
# # CREATE ZIPFILE
# shutil.make_archive('new_archive_folder', 'zip', 'neural_style_transfer')

print(os.getcwd())
os.chdir(r'C:\Users\vamsh\Videos\Python Pycharm Projects')
print(os.getcwd())

import shutil

shutil.make_archive('file_operations.zip','zip', 'C:\Users\vamsh\Videos\Python Pycharm Projects\File_Operations\')
























